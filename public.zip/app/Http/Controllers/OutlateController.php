<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Outlate;
use App\File;
class OutlateController extends Controller
{
    public function index(){
        $data = Outlate::
        join('files','files.id','outlates.banner')
        ->get();
    //    dd($data);
         return view('backend.outlate.index')->with('data',$data);
     }
 
     public function create(){
         
         // $parent_cats=Category::where('is_parent',1)->orderBy('title','ASC')->get();
         return view('backend.outlate.create');
     }
 
     public function store(Request $request ){

       
         $location = $request->input('latitude').','.$request->input('longitude');
        //  dd($request);
         $addFile = new File; 
         if($request->has('image'))
        {
         $file=  request('image');
         $filepath=$file->move(public_path().'\menu',$file->getClientOriginalName());  
         $path = $file->getClientOriginalName(); 
         // $realpath = explode('C:\xampp\htdocs\foodapp\public' , $filepath);
         // print_r($realpath);exit;
         $addFile->path= $path;  
        }
         $addFile->save();
 
         $addOutlates = new Outlate();
         $addOutlates->banner = $addFile->id;
         $addOutlates->name = $request->input('name');
         $addOutlates->address = $request->input('address');
         $addOutlates->location = $location;
         $addOutlates->phone = $request->input('phone');
         $addOutlates->start = $request->input('start');
         $addOutlates->end = $request->input('end');
         $addOutlates->save();
 
         return redirect('admin/outlate');
     }
 
}
