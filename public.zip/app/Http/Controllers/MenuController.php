<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Str;
use App\Pro_menu;
use App\File;
use DB;



class MenuController extends Controller
{
    public function index(){
       $data = File::
       join('pro_menus','pro_menus.banner','files.id')
       ->get();
      
        return view('backend.menu.index')->with('data',$data);
    }

    public function create(){
        
        // $parent_cats=Category::where('is_parent',1)->orderBy('title','ASC')->get();
        return view('backend.menu.create');
    }

    public function store(Request $request ){
        $addFile = new File; 
        if($request->has('image'))
       {
        $file=  request('image');
        $filepath=$file->move(public_path().'\menu',$file->getClientOriginalName());  
        $path = $file->getClientOriginalName(); 
        // $realpath = explode('C:\xampp\htdocs\foodapp\public' , $filepath);
        // print_r($realpath);exit;
        $addFile->path= $path;  
       }
        $addFile->save();

        $addmenu = new Pro_menu();
        $addmenu->banner = $addFile->id;
        $addmenu->name = $request->input('name');
        $addmenu->save();

        return redirect('admin/menu');
    }

    public function edit($id)
    { 
       
        $datas = File:: join('pro_menus','pro_menus.banner','files.id')
        ->where('pro_menus.id',$id)->get();
        
        foreach($datas as $data){
            return view('backend.menu.edit')->with('menu',$data);
        }
       
    }
    public function delete(Request $request){
    //    dd($request);
       $menu = Pro_menu::find($request->id);
       $menu->delete();
    }
}
