<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Outlate extends Model
{
    protected $table = "outlates";
    public $fillable = [];
}
